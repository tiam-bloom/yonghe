package fit.yujing.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import fit.yujing.pojo.Door;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Tiam
 * @date 2023/4/14 23:10
 * @description
 */
@Mapper
public interface DoorMapper extends BaseMapper<Door> {

}
