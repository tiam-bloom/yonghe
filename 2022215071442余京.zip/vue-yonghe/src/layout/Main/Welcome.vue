<template>
  <div class="wrapper">
    <h3 class="text-linear">欢迎使用永和大王门店管理系统</h3>
  </div>
</template>

<script setup lang='ts'>

</script>

<style lang='less' scoped>
.wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 100px auto 0;
  font-size: 30px;
}

.text-linear {
  background-image: linear-gradient(to right, #0c02ba, #00ff95);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  /* 或者设置 color: transparent */
}
</style>